import React from "react";



const BanList = ({banList, handleUnban}) => {


    return(

        <>
            <div className="banList">
                <h2>Ban List</h2>
                <p>Select an attribute in your listing to ban it</p>
                <p>Click to Remove</p>
                <ul>
                    {banList.length === 0 ? <p>No bans yet.</p> :
                    banList.map((item, idx) => (
                        <li key={idx} onClick={() => handleUnban(item)}>
                            {item}
                        </li>
                    ))}
                </ul>
            </div>
        </>
    )


}

export default BanList;