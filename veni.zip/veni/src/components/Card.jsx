import React from "react";

import { fetchImages } from "./APIService";



const Card = ({cat, handleBan}) => {

    if (!cat || !cat.breeds || cat.breeds.length ===0) {

        return ( <div className="error">
            <p>No cat data available</p>
        </div>
        );
    }

    const {name, id, weight, origin, life_span} = cat.breeds[0];
   
    

    return(

        <>
        <div className="cat_card">
            
            <h1 className="cat_id">{id}</h1>
            <div className="attr">
                <button className="breed" onClick={() => handleBan(name)}>{name}</button>
                <button className="weight" onClick={() => handleBan(weight.imperial)}>{weight.imperial} lbs</button>
                <button className="origin" onClick={() => handleBan(origin)}>{origin}</button>
                <button className="life_span" onClick={() => handleBan(life_span)}>{life_span} years</button>
            </div>

            <img src={cat.url} alt="" className="cat_pic" />

        </div>
        
        </>

    )


}


export default Card;