

export async function fetchImages() {
    const response = await fetch("https://api.thecatapi.com/v1/images/search?limit=10&has_breeds=1&api_key=live_Zbr3lOI33AERMnhvUfYjQNIPL0a3GMuyrgfs1FxfW71nrVTlYsR6adagfuKCHPIe");
    const data = await response.json();
    return data.length > 0 ? data[0] : null; // Return null if no valid data
}
