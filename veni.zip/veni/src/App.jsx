import "./App.css";
import React from "react";
import { useState, useEffect } from "react";
import { fetchImages } from "./components/APIService";
import Card from "./components/Card";
import BanList from "./components/BanList";

 

const App = () => {

  const [cat, setCat] = useState(null);
  const [banList, setBanList] = useState([]);

  useEffect(() => {
      getNewCat();
  }, []);

  // App.js
const getNewCat = async () => {
  let newCat;
  do {
    newCat = await fetchImages();
    // Check if newCat is valid and has breeds before checking ban status
    if (!newCat || !newCat.breeds || newCat.breeds.length === 0) {
      continue; // Skip invalid cats and fetch again
    }
  } while (isBanned(newCat));
  setCat(newCat);
};

const isBanned = (newCat) => {
  if (!newCat || !newCat.breeds || newCat.breeds.length === 0) {
    return false;
  }
  const { name, id, origin, weight, life_span } = newCat.breeds[0];
  return banList.includes(name) || banList.includes(id) || banList.includes(origin) || banList.includes(weight.imperial) || banList.includes(life_span);
};

  const handleBan = (attribute) => {
      setBanList([...banList, attribute]);
  };

  const handleUnban = (attribute) => {
      setBanList(banList.filter((item) => item !== attribute));
  };


return(

  <div className="App">
      <h1 className="title">Trippin' on Cats</h1>
      <p>Discover cats from your wildest dreams!</p>
      <p>😺😸😹😻😼😽🙀😿😾</p>
      <Card cat={cat} handleBan={handleBan}></Card>
      <button onClick={getNewCat}>Discover</button>
      <BanList banList = {banList} handleUnban={handleUnban}></BanList>
  </div>

)

}

export default App;